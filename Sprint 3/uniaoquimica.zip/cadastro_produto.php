<?php
// cadastro_produto.php
include 'valida_sessao.php';
require_once 'conexao.php';

$mensagem = '';
$erro = '';

function salvarImagem($arquivo) {
    $dir = "img/";
    if (!file_exists($dir)) mkdir($dir, 0777, true);
    $ext = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif'])) return "Formato inválido.";
    if ($arquivo['size'] > 5*1024*1024) return "Arquivo muito grande.";
    $nome = uniqid() . '.' . $ext;
    $dest = $dir . $nome;
    if (!move_uploaded_file($arquivo['tmp_name'], $dest)) return "Erro ao salvar imagem.";
    return $dest;
}

// POST inserir / atualizar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $codigo = $conn->real_escape_string($_POST['codigo'] ?? '');
    $nome_p = $conn->real_escape_string($_POST['nome_p'] ?? '');
    $preco = str_replace(',', '.', $_POST['preco'] ?? '0');
    $preco = $conn->real_escape_string($preco);
    $estoque = intval($_POST['estoque'] ?? 0);
    $descricao = $conn->real_escape_string($_POST['descricao'] ?? '');
    $cnpj_fornecedor = $conn->real_escape_string($_POST['cnpj_fornecedor'] ?? '');

    $imagem = '';
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === 0) {
        $res = salvarImagem($_FILES['imagem']);
        if (strpos($res, 'img/') === 0) $imagem = $conn->real_escape_string($res);
        else $erro = $res;
    }

    if (!empty($codigo)) {
        // update
        $sql = "UPDATE produtos 
                SET nome_p='$nome_p', preco='$preco', estoque='$estoque', descricao='$descricao', 
                    cnpj_fornecedor='$cnpj_fornecedor'";
        if ($imagem) $sql .= ", imagem='$imagem'";
        $sql .= " WHERE codigo = '$codigo'";

        if ($conn->query($sql)) $mensagem = "Produto atualizado.";
        else $erro = "Erro: " . $conn->error;

    } else {
        // insert
        $sql = "INSERT INTO produtos (nome_p, preco, estoque, descricao, cnpj_fornecedor, imagem)
                VALUES ('$nome_p', '$preco', '$estoque', '$descricao', '$cnpj_fornecedor', '$imagem')";
        if ($conn->query($sql)){ $mensagem = "Produto cadastrado.";
        }else { $erro = "Erro: " . $conn->error;
        }
    }

    $_SESSION['mensagem'] = $mensagem ?: $erro;
    header('Location: cadastro_produto.php');
    exit();
}

// exclusão via GET
if (isset($_GET['delete_id'])) {
    $del = intval($_GET['delete_id']);
    if ($conn->query("DELETE FROM produtos WHERE codigo = $del")) 
        $_SESSION['mensagem'] = "Produto excluído.";
    else 
        $_SESSION['mensagem'] = "Erro: " . $conn->error;

    header('Location: cadastro_produto.php');
    exit();
}

// dados para formulario
$fornecedores = $conn->query("SELECT CNPJ, nome_f FROM fornecedores ORDER BY nome_f ASC");

$produtos = $conn->query("
    SELECT p.*, f.nome_f AS fornecedor_nome 
    FROM produtos p 
    LEFT JOIN fornecedores f ON p.cnpj_fornecedor = f.CNPJ
    ORDER BY p.nome_p ASC
");

$edit = null;
if (isset($_GET['edit_id'])) {
    $id = intval($_GET['edit_id']);
    $r = $conn->query("SELECT * FROM produtos WHERE codigo = $id LIMIT 1");
    if ($r && $r->num_rows > 0) $edit = $r->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Cadastro Produto</title>
<link rel="stylesheet" href="style_produtos.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>

<div class="tela-preta"></div>

    <video id="background-video" autoplay loop muted playsinline >
    <source src="https://res.cloudinary.com/dh7vltxdt/video/upload/v1765309564/2_lzt2oo.mp4" type="video/mp4">
</video>

<div class="fundo-overlay"></div>

 <header class="header-fixo">
    <img src="Pictures/enzoavanze.png" class="logo-header" alt="Logo">
</header>


<div class="container">
  <h2>Cadastro de Produto</h2>

  <?php if (!empty($_SESSION['mensagem'])) { 
      echo '<p class="message">'.htmlspecialchars($_SESSION['mensagem']).'</p>'; 
      unset($_SESSION['mensagem']); 
    } 
  ?>

  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="codigo" value="<?php echo htmlspecialchars($edit['codigo'] ?? ''); ?>">

    <label>Nome:</label>
    <input type="text" name="nome_p" value="<?php echo htmlspecialchars($edit['nome_p'] ?? ''); ?>" required>

    <label>Preço:</label>
    <input type="text" name="preco" value="<?php echo htmlspecialchars(isset($edit['preco']) ? number_format($edit['preco'], 2, ',', '.') : ''); ?>" required>

    <label>Estoque:</label>
    <input type="number" name="estoque" value="<?php echo htmlspecialchars($edit['estoque'] ?? 0); ?>" required>

    <label>Descrição:</label>
    <textarea name="descricao"><?php echo htmlspecialchars($edit['descricao'] ?? ''); ?></textarea>

    <label>Fornecedor:</label>
    <select name="cnpj_fornecedor" required>
      <option value="">-- escolha --</option>
      <?php
      $fornecedores->data_seek(0);
      while ($f = $fornecedores->fetch_assoc()):
      ?>
        <option value="<?php echo htmlspecialchars($f['CNPJ']); ?>"
          <?php if (($edit['cnpj_fornecedor'] ?? '') == $f['CNPJ']) echo 'selected'; ?>>
          <?php echo htmlspecialchars($f['nome_f']); ?>
        </option>
      <?php endwhile; ?>
    </select>

    <label>Imagem:</label>
    <input type="file" name="imagem" accept="image/*">

    <?php if (!empty($edit['imagem'])): ?>
        <img src="<?php echo htmlspecialchars($edit['imagem']); ?>" style="max-width:100px;">
    <?php endif; ?>

    <button type="submit"><?php echo $edit ? 'Atualizar' : 'Cadastrar'; ?></button>
  </form>

  <h2>Listagem de Produtos</h2>
    
<div class="container-table">
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Preço</th>
        <th>Estoque</th>
        <th>Fornecedor</th>
        <th>Imagem</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $produtos->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['codigo']); ?></td>
          <td><?php echo htmlspecialchars($row['nome_p']); ?></td>
          <td><?php echo 'R$ ' . number_format($row['preco'], 2, ',', '.'); ?></td>
          <td><?php echo htmlspecialchars($row['estoque']); ?></td>
          <td><?php echo htmlspecialchars($row['fornecedor_nome']); ?></td>
          <td><?php echo $row['imagem'] ? '<img src="'.htmlspecialchars($row['imagem']).'" style="max-width:80px;">' : 'Sem imagem'; ?></td>
           <td class="acoes">
    <a href="?edit_id=<?= urlencode($row['codigo']) ?>" class="edit-btn">
        <i class="fa-solid fa-pen-to-square"></i>
    </a>
    <a href="?delete_id=<?= urlencode($row['codigo']) ?>" class="delete-btn" 
       onclick="return confirm('Excluir produto?')">
        <i class="fa-solid fa-trash"></i>
    </a>
</td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  </div>

  <a href="index.php">Voltar</a>

</div>
    
    
</body>
</html>
