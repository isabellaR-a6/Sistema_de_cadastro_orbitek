<?php
session_start();
require_once 'conexao.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $conn->real_escape_string($_POST['usuario'] ?? '');
    $senha = $conn->real_escape_string($_POST['senha'] ?? '');

    $sql = "SELECT ID, Usuario, Senha FROM usuario WHERE Usuario = '$usuario' LIMIT 1";
    $res = $conn->query($sql);

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();

        if (function_exists('password_verify') && password_verify($senha, $row['Senha'])) {
            $_SESSION['usuario'] = $row['Usuario'];
            header('Location: index.php');
            exit();
        }

        if ($senha === $row['Senha']) {
            $_SESSION['usuario'] = $row['Usuario'];
            header('Location: index.php');
            exit();
        }
    }
    $error = "Usuário ou senha inválidos.";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link rel="stylesheet" href="style_login.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
  
<body>

<div class="tela-preta"></div>

    <video id="background-video" autoplay loop muted playsinline>
    <source src="https://res.cloudinary.com/dh7vltxdt/video/upload/v1765295710/1_e4teva.mp4" type="video/mp4">
</video>

<div class="fundo-overlay"></div>

  <header class="header-fixo">
    <img src="Pictures/enzoavanze.png" class="logo-header" alt="Logo">
</header>

<!-- POPUP DE RECUPERAÇÃO DE SENHA -->
<div id="forgot-popup" class="popup">
    <div class="popup-box">

        <a href="#" class="close-popup">&times;</a>

        <h3>Recuperar Senha</h3>
        <p>Digite seu e-mail para enviarmos o link de recuperação:</p>

        <form action="recuperar.php" method="post">
            <input type="email" name="email" placeholder="Seu e-mail" required>
            <button type="submit">Enviar</button>
        </form>

    </div>
</div>
<!-- FIM DO POPUP -->

<div class="container">
  <h2>Área Restrita</h2>

  <form method="post" action="">

    <!-- INPUT COM FLOATING LABEL -->
    <div class="input-box">
        <input type="text" name="usuario" required placeholder=" ">
        <label>E-mail</label>
    </div>

    <div class="input-box">
        <input type="password" name="senha" required placeholder=" ">
        <label>Senha</label>
    </div>

    <!-- OPÇÕES -->
    <div class="options">
        <label class="remember">
            <input type="checkbox" name="lembrar">
            <span class="checkmark"></span>
            Lembrar-me
        </label>

        <!-- AGORA ABRE A TELA -->
        <a href="#forgot-popup" class="forgot-link">Esqueceu sua senha?</a>
    </div>

    <button type="submit">Entrar</button>

  </form>

  <?php if ($error): ?>
      <p class="message error"><?php echo htmlspecialchars($error); ?></p>
  <?php endif; ?>

</div>

    
</body>
</html>
