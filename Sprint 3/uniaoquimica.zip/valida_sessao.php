<?php
// valida_acesso.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// verifica se está logado
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

/*
    Funções de proteção por nível de acesso
*/

function somenteAdmin() {
    if ($_SESSION['nivel'] !== 'admin') {
        die("<h2>🚫 Acesso negado. Apenas administradores podem acessar esta página.</h2>");
    }
}

function somenteFornecedor() {
    if ($_SESSION['nivel'] !== 'fornecedor') {
        die("<h2>🚫 Acesso negado. Esta página é exclusiva para fornecedores.</h2>");
    }
}
?>
