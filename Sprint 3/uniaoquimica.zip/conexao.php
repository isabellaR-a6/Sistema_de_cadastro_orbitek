<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "sql101.infinityfree.com";
$username   = "if0_40547692";
$password   = "Orbitech12345";
$dbname     = "if0_40547692_orbitech_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
