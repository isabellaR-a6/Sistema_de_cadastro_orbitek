<?php
// index.php
include 'valida_sessao.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Painel Principal</title>
<link rel="stylesheet" href="style_index.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
  <div class="tela-preta"></div>

      <video id="background-video" autoplay loop muted playsinline>
    <source src="https://res.cloudinary.com/dh7vltxdt/video/upload/v1765309572/1_tsdmma.mp4" type="video/mp4">
</video>

<div class="fundo-overlay"></div>

    <header class="header-fixo">
    <img src="Pictures/enzoavanze.png" class="logo-header" alt="Logo">
</header>


<div class="container">
  <h2>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario']); ?></h2>

  <ul class="menu-list">
<li>
  <a href="cadastro_fornecedor.php" style="--clr:#ff3b3b;">
    <i class="fa-solid fa-user"></i>
    <span>Cadastro de Fornecedores</span>
  </a>
</li>

<li>
  <a href="cadastro_produto.php" style="--clr:#00a86b;">
    <span><i class="fas fa-box"></i>&nbsp;&nbsp;Cadastro de Produtos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
  </a>
</li>

<li>
  <a href="listagem_produtos.php" style="--clr:#0066ff;">
    
    <span><i class="fas fa-list"></i>&nbsp;&nbsp;Listagem de Produtos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
  </a>
</li>

</ul>

  <a href="logout.php" class="logout-button">Sair</a>

</div>
    
</body>
</html>
