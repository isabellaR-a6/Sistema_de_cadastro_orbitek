<?php
include 'valida_sessao.php';
require_once 'conexao.php';

$mensagem = '';
$erro = '';

/* UPLOAD DE IMAGEM */
function salvarImagem($arquivo) {
    $dir = "assets/img/fornecedores/";
    if (!file_exists($dir)) mkdir($dir, 0777, true);

    $ext = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif'])) return "Formato inválido.";

    if ($arquivo['size'] > 5*1024*1024) return "Arquivo muito grande.";

    $nome = uniqid() . '.' . $ext;
    $dest = $dir . $nome;

    if (!move_uploaded_file($arquivo['tmp_name'], $dest)) return "Erro ao salvar imagem.";

    return $dest;
}

/* SALVAR / EDITAR */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ID = isset($_POST['ID']) ? intval($_POST['ID']) : 0;
    $CNPJ = $conn->real_escape_string($_POST['CNPJ']);
    $nome_f = $conn->real_escape_string($_POST['nome_f']);
    $email = $conn->real_escape_string($_POST['email']);
    $telefone = $conn->real_escape_string($_POST['telefone']);
    $observacoes = $conn->real_escape_string($_POST['observacoes']);
    $endereco = $conn->real_escape_string($_POST['endereco']);

    $imagem = '';

    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === 0) {
        $res = salvarImagem($_FILES['imagem']);
        if (strpos($res, 'assets/') === 0) {
            $imagem = $conn->real_escape_string($res);
        } else {
            $erro = $res;
        }
    }

// Verifica se o ID existe
$stmt = $conn->prepare("SELECT ID FROM fornecedores WHERE ID = ?");
$stmt->bind_param("i", $ID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {

    // ----------------------
    //        UPDATE
    // ----------------------

    if ($imagem) {

        $sql = "UPDATE fornecedores SET 
                    CNPJ=?,
                    nome_f=?, 
                    email=?, 
                    telefone=?, 
                    observacoes=?, 
                    endereco=?, 
                    imagem=?
                WHERE ID=?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "sssssssi",
            $CNPJ,
            $nome_f,
            $email,
            $telefone,
            $observacoes,
            $endereco,
            $imagem,
            $ID
        );

    } else {

        $sql = "UPDATE fornecedores SET 
                    CNPJ=?, 
                    nome_f=?, 
                    email=?, 
                    telefone=?, 
                    observacoes=?, 
                    endereco=?
                WHERE ID=?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "ssssssi",
            $CNPJ,
            $nome_f,
            $email,
            $telefone,
            $observacoes,
            $endereco,
            $ID
        );
    }

    $stmt->execute();

} else {

    // ----------------------
    //        INSERT
    // ----------------------

    $sql = "INSERT INTO fornecedores 
            (CNPJ, nome_f, email, telefone, observacoes, endereco, imagem)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssss",
        $CNPJ,
        $nome_f,
        $email,
        $telefone,
        $observacoes,
        $endereco,
        $imagem    // pode ser NULL sem problema
    );

    if ($stmt->execute()) {
        $mensagem = "Fornecedor cadastrado com sucesso!";
    } else {
        $erro = "Erro ao cadastrar fornecedor: " . $stmt->error;
    }
}

header("Location: cadastro_fornecedor.php");
exit();
}


/* EXCLUSÃO */
if (isset($_GET['delete_id'])) {
    $del = $conn->real_escape_string($_GET['delete_id']);
    $conn->query("DELETE FROM fornecedores WHERE CNPJ = '$del'");
    header("Location: cadastro_fornecedor.php");
    exit();
}

/* CARREGAR LISTAGEM / EDIÇÃO */
$fornecedores = $conn->query("SELECT * FROM fornecedores ORDER BY nome_f ASC");
$edit = null;

if (isset($_GET['edit_id'])) {
    $id = $conn->real_escape_string($_GET['edit_id']);
    $r = $conn->query("SELECT * FROM fornecedores WHERE ID = '$id' LIMIT 1");
    if ($r->num_rows > 0) $edit = $r->fetch_assoc();
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Cadastro de Fornecedor</title>
    <link rel="stylesheet" href="style_fornecedor.css">
    <link rel="icon" type="image/svg+xml" href="<i class="fa-thin fa-flask"></i>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<body>
    <div class="tela-preta"></div>

    <video id="background-video" autoplay loop muted playsinline>
    <source src="https://res.cloudinary.com/dh7vltxdt/video/upload/v1765309569/5_pg18sc.mp4" type="video/mp4">
</video>

<div class="fundo-overlay"></div>
    
  <header class="header-fixo">
    <img src="Pictures/enzoavanze.png" class="logo-header" alt="Logo">
</header>


<div class="container">
    <h2>Cadastro de Fornecedor</h2>

    <form method="post" enctype="multipart/form-data">

    <?php if ($edit): ?>
        <!-- Campo oculto que envia o ID para o update -->
        <input type="hidden" name="ID" value="<?= htmlspecialchars($edit['ID']) ?>">
    <?php endif; ?>

<div class="form-bloco">

    <div class="campo">
        <label>CNPJ:</label>
        <input type="text" name="CNPJ" 
               value="<?= $edit ? htmlspecialchars($edit['CNPJ']) : '' ?>" 
               required>
    </div>

    <div class="campo">
        <label>Nome:</label>
        <input type="text" name="nome_f" 
               value="<?= $edit ? htmlspecialchars($edit['nome_f']) : '' ?>" 
               required>
    </div>

    <div class="campo">
        <label>Email:</label>
        <input type="email" name="email" 
               value="<?= $edit ? htmlspecialchars($edit['email']) : '' ?>" 
               required>
    </div>

    <div class="campo">
        <label>Telefone:</label>
        <input type="text" name="telefone" 
               value="<?= $edit ? htmlspecialchars($edit['telefone']) : '' ?>" 
               required>
    </div>

    <div class="campo">
        <label>Endereço:</label>
        <input type="text" name="endereco" 
               value="<?= $edit ? htmlspecialchars($edit['endereco']) : '' ?>" 
               required>
    </div>

    <div class="campo">
        <label>Observações:</label>
        <input type="text" name="observacoes" 
               value="<?= $edit ? htmlspecialchars($edit['observacoes']) : '' ?>">
    </div>

    <div class="campo-full">
        <label>Imagem:</label>
        <input type="file" name="imagem" <?= $edit ? '' : 'required' ?>>
    </div>

</div>

<?php if (!empty($edit['imagem'])): ?>
    <img src="<?= htmlspecialchars($edit['imagem']) ?>" class="foto-produto">
<?php endif; ?>

<button type="submit" class="btn-cadastrar">
    <?= $edit ? "Atualizar" : "Cadastrar" ?>
</button>

</form>


    <h2>Lista de Fornecedores</h2>

    <div class="table-container">

    <table>
        <tr>
            <th>ID</th>
            <th>CNPJ</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Telefone</th>
            <th>Endereço</th>
            <th>Observações</th>
            <th>Imagem</th>
            <th>Ações</th>
        </tr>

        <?php while ($row = $fornecedores->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['ID']) ?></td>
            <td><?= htmlspecialchars($row['CNPJ']) ?></td>
            <td><?= htmlspecialchars($row['nome_f']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['telefone']) ?></td>
            <td><?= htmlspecialchars($row['endereco']) ?></td>
            <td><?= htmlspecialchars($row['observacoes']) ?></td>
            <td>
                <?= $row['imagem'] 
    ? "<img src='".htmlspecialchars($row['imagem'])."' class='foto-produto'>" 
    : "Sem imagem" 
?>

            </td>
            <td class="acoes">
             <a href="?edit_id=<?= urlencode($row['ID']) ?>" class="edit-btn">
             <i class="fa-solid fa-pen-to-square"></i>
            </a>

             <a href="?delete_id=<?= urlencode($row['CNPJ']) ?>" class="delete-btn" 
              onclick="return confirm('Excluir fornecedor?')">
            <i class="fa-solid fa-trash"></i>
           </a>
           </td>

        </tr>
        <?php endwhile; ?>
    </table>

    </div>

    <ul class="menu-sair">
    <li>
        <a href="index.php">Sair</a>
    </li>
</ul>

</div>
    

</body>
</html>
