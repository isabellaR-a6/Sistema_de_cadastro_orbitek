<?php
// listagem_produtos.php
include 'valida_sessao.php';
require_once 'conexao.php';

$produtos = $conn->query("
    SELECT 
        p.codigo, 
        p.nome_p, 
        p.descricao, 
        p.preco, 
        p.estoque, 
        p.imagem, 
        f.nome_f AS fornecedor_nome
    FROM produtos p 
    LEFT JOIN fornecedores f 
        ON p.cnpj_fornecedor = f.CNPJ 
    ORDER BY p.nome_p ASC
");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head><meta charset="utf-8"><title>Listagem de Produtos</title>
<link rel="stylesheet" href="style_listagem_produtos.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
<body>

<div class="tela-preta"></div>

    <video id="background-video" autoplay loop muted playsinline>
    <source src="https://res.cloudinary.com/dh7vltxdt/video/upload/v1765309601/4_wrmca5.mp4" type="video/mp4">
</video>

<div class="fundo-overlay"></div>
    
  <header class="header-fixo">
    <img src="Pictures/enzoavanze.png" class="logo-header" alt="Logo">
</header>

<div class="container">
  <h2>Listagem de Produtos</h2>
  <div class="container-table">
  <table>
    <thead><tr><th>ID</th><th>Nome</th><th>Descricao</th><th>Preço</th><th>Fornecedor</th><th>Estoque</th><th>Imagem</th></tr></thead>
    <tbody>
    <?php while ($row = $produtos->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($row['codigo']); ?></td>
        <td><?php echo htmlspecialchars($row['nome_p']); ?></td>
        <td><?php echo htmlspecialchars($row['descricao']); ?></td>
        <td><?php echo 'R$ ' . number_format($row['preco'], 2, ',', '.'); ?></td>
        <td><?php echo htmlspecialchars($row['fornecedor_nome']); ?></td>
        <td><?php echo htmlspecialchars($row['estoque']); ?></td>
        <td><?php echo $row['imagem'] ? '<img src="'.htmlspecialchars($row['imagem']).'" style="max-width:80px;">' : 'Sem imagem'; ?></td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<a href="index.php">Voltar</a>
</div>

    
</body>
</html>
